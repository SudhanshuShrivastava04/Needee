<?php
$to = "sudhanshushrivastava004@gmail.com";
$subject = "New form submission";
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$headers = "From: $email";
// Send the email
mail($to, $subject, $message, $headers);
// Redirect the user back to the form page
header("Location: index.html");
exit;
?>