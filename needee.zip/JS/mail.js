import { initializeApp } from "https://www.gstatic.com/firebasejs/9.20.0/firebase-app.js";

const firebaseConfig = {
    apiKey: "AIzaSyCv-wrr12taI5TdQfTFeQ7ChFUABwR0e9M",
    authDomain: "contactform-needee.firebaseapp.com",
    databaseURL: "https://contactform-needee-default-rtdb.firebaseio.com",
    projectId: "contactform-needee",
    storageBucket: "contactform-needee.appspot.com",
    messagingSenderId: "816776854615",
    appId: "1:816776854615:web:499235e5cb9a2bb402f712"
};

const app = firebase.initializeApp(firebaseConfig);
var contactFormDB =firebaseConfig.database().ref("contactform-needee");


document.getElementById("contactForm").addEventListener("submit",submitForm);

function submitForm(e){
    e.preventDefault();
    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;
    console.log(name + ": " + phone + ": " + email + ": " + message);
    saveMessages(name, phone, email, message);
    document.getElementById("contactForm").reset();
    alert("Your message has been sent!");
}

const saveMessages = (name, phone, email, message) => {
    var newContactForm = contactFormDB.push();

    newContactForm.set({
        name: name,
        phone: phone,
        email: email,
        message: message
    })
}
