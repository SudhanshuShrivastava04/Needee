lightbox.option({
  resizeDuration: 200,
  wrapAround: true ,
  disableScrolling: true ,
  albumLabel : 'Image %1' ,
  fitImagesInViewport : true,
});
